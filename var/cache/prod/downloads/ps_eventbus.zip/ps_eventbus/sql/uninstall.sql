DROP TABLE IF EXISTS `PREFIX_eventbus_type_sync`;
DROP TABLE IF EXISTS `PREFIX_eventbus_job`;
DROP TABLE IF EXISTS `PREFIX_eventbus_incremental_sync`;
DROP TABLE IF EXISTS `PREFIX_eventbus_live_sync`;
