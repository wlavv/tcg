const e=document.createElement("script");e.type="text/javascript";e.src=document.currentScript.src.replace("app.js","pssocial-ui.js");e.type="module";document.head.append(e);
